DATAPACK: Spawns dos Lendarios Faltantes (Cobblemon 1.7.3 / MC 1.21.1)
=====================================================================
60 pokemons lendarios/miticos/ultra beasts/paradox com spawn natural.

Raridade: bucket "ultra-rare" + weight 0.15-0.25 = bem raros.
Condicoes tematicas por pokemon (bioma, dia/noite, tempestade, altitude...).

COMO INSTALAR (mundo single/server):
  1. Copie a pasta "datapack_lendarios_spawns" (ou o .zip)
     para: <seu_mundo>/datapacks/
  2. Entre no mundo e rode: /reload
  3. Confira: /datapack list

Ex de temas:
  Kyogre   -> oceano profundo (submerso)
  Groudon  -> deserto/vulcanico
  Rayquaza -> picos altos (Y>=160)
  Solgaleo -> picos de dia | Lunala -> picos de noite
  Ultra Beasts -> bioma do End
  Forces of Nature / Raging Bolt -> durante tempestade
