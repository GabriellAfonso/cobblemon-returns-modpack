execute in minecraft:the_end run spawnpokemonat 0 70 0 rayquaza shiny=yes level=100
scoreboard players set #spawned rayquazaend 1
