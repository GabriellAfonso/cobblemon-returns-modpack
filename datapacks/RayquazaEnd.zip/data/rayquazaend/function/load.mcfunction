scoreboard objectives add rayquazaend dummy
