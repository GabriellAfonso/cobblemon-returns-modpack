cobbledollars give @s 20000
