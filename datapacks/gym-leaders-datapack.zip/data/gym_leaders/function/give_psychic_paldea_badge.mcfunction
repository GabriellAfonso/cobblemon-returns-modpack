give @s pokebadges:psychic_paldea_badge
cobbledollars give @s 274000
