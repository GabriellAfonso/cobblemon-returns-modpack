give @s pokebadges:bug_paldea_badge
cobbledollars give @s 226000
