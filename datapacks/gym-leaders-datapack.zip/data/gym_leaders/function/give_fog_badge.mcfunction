give @s pokebadges:fog_johto_badge
cobbledollars give @s 18000
