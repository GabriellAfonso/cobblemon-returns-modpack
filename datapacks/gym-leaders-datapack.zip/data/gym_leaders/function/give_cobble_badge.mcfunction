give @s pokebadges:cobble_sinnoh_badge
cobbledollars give @s 60000
