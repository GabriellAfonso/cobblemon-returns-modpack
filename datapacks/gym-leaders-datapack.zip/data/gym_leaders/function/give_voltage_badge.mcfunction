give @s pokebadges:voltage_kalos_badge
cobbledollars give @s 147000
