give @s pokebadges:normal_paldea_badge
cobbledollars give @s 258000
