give @s pokebadges:insect_unova_badge
cobbledollars give @s 94000
