give @s pokebadges:mineral_johto_badge
cobbledollars give @s 22000
