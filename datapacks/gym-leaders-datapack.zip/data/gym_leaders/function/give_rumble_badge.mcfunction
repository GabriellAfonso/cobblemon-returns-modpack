give @s pokebadges:rumble_kalos_badge
cobbledollars give @s 135000
