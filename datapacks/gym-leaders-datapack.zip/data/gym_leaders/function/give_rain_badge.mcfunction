give @s pokebadges:rain_hoenn_badge
cobbledollars give @s 49000
