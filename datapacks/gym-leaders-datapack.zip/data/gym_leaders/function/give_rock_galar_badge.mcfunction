give @s pokebadges:rock_galar_badge
cobbledollars give @s 205000
