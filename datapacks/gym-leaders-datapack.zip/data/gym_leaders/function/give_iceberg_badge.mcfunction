give @s pokebadges:iceberg_kalos_badge
cobbledollars give @s 165000
