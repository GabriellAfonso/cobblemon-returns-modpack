give @s pokebadges:grass_galar_badge
cobbledollars give @s 170000
