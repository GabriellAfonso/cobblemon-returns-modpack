give @s pokebadges:water_galar_badge
cobbledollars give @s 177000
