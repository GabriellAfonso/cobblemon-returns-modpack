give @s pokebadges:water_galar_badge
cobbledollars give @s 354000
give @s cobblemon:rare_candy 1
give @s cobblemon:health_mochi 1
give @s cobblemon:muscle_mochi 1
give @s cobblemon:resist_mochi 1
give @s cobblemon:genius_mochi 1
give @s cobblemon:clever_mochi 1
give @s cobblemon:swift_mochi 1
