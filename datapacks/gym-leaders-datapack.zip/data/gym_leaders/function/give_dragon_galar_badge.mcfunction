give @s pokebadges:dragon_galar_badge
cobbledollars give @s 219000
