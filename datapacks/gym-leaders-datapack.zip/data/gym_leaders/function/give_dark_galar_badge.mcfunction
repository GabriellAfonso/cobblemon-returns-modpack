give @s pokebadges:dark_galar_badge
cobbledollars give @s 212000
