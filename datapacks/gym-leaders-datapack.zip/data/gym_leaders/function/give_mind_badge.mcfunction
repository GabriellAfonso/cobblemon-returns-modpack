give @s pokebadges:mind_hoenn_badge
cobbledollars give @s 46000
