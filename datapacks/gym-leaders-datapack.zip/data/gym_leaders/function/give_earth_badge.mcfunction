give @s pokebadges:earth_kanto_badge
cobbledollars give @s 10000
