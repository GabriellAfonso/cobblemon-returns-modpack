give @s pokebadges:volcano_kanto_badge
cobbledollars give @s 9000
