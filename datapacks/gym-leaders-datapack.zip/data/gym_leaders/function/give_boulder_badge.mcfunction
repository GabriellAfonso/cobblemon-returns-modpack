give @s pokebadges:boulder_kanto_badge
cobbledollars give @s 3000
