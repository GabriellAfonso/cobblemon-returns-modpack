give @s pokebadges:plain_johto_badge
cobbledollars give @s 16000
