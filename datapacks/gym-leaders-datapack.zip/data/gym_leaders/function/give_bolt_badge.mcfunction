give @s pokebadges:bolt_unova_badge
cobbledollars give @s 99000
