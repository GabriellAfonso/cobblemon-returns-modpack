give @s pokebadges:marsh_kanto_badge
cobbledollars give @s 8000
