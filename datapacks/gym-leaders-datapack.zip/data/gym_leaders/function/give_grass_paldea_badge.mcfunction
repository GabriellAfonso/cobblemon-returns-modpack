give @s pokebadges:grass_paldea_badge
cobbledollars give @s 234000
