give @s pokebadges:ice_paldea_badge
cobbledollars give @s 282000
