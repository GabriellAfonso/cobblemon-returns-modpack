give @s pokebadges:fire_galar_badge
cobbledollars give @s 184000
