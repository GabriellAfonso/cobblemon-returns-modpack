give @s pokebadges:forest_sinnoh_badge
cobbledollars give @s 56000
