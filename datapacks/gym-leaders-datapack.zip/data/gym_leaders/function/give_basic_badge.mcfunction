give @s pokebadges:basic_unova_badge
cobbledollars give @s 89000
