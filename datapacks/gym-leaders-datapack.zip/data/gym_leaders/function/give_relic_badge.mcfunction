give @s pokebadges:relic_sinnoh_badge
cobbledollars give @s 68000
