give @s pokebadges:legend_unova_badge
cobbledollars give @s 119000
