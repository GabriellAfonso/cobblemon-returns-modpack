give @s pokebadges:electric_paldea_badge
cobbledollars give @s 242000
