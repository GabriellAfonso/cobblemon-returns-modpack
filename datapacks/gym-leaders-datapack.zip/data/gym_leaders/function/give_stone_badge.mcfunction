give @s pokebadges:stone_hoenn_badge
cobbledollars give @s 28000
