give @s pokebadges:coal_sinnoh_badge
cobbledollars give @s 52000
