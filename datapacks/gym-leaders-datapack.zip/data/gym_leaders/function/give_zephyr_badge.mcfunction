give @s pokebadges:zephyr_johto_badge
cobbledollars give @s 12000
