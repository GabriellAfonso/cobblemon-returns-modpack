give @s pokebadges:thunder_kanto_badge
cobbledollars give @s 5000
