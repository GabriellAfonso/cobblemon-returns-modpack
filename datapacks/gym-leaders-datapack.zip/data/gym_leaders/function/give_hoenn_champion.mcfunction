cobbledollars give @s 98000
