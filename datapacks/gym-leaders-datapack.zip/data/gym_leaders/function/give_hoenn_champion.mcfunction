cobbledollars give @s 196000
give @s cobblemon:rare_candy 5
give @s cobblemon:hp_up 1
give @s cobblemon:protein 1
give @s cobblemon:iron 1
give @s cobblemon:calcium 1
give @s cobblemon:zinc 1
give @s cobblemon:carbos 1
