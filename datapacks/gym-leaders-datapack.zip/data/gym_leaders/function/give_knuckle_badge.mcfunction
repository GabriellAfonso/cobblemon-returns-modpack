give @s pokebadges:knuckle_hoenn_badge
cobbledollars give @s 31000
