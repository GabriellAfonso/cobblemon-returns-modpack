give @s pokebadges:hive_johto_badge
cobbledollars give @s 14000
