give @s pokebadges:dynamo_hoenn_badge
cobbledollars give @s 34000
