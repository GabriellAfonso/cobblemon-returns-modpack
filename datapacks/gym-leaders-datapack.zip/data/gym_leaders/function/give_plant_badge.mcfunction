give @s pokebadges:plant_kalos_badge
cobbledollars give @s 141000
