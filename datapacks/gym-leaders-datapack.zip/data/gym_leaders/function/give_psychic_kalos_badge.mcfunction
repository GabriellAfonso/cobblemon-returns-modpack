give @s pokebadges:psychic_kalos_badge
cobbledollars give @s 159000
