give @s pokebadges:fighting_galar_badge
cobbledollars give @s 191000
