give @s pokebadges:ice_galar_badge
cobbledollars give @s 205000
