cobbledollars give @s 330000
