give @s pokebadges:beacon_sinnoh_badge
cobbledollars give @s 80000
