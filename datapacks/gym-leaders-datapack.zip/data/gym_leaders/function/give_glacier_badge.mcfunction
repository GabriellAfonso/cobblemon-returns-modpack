give @s pokebadges:glacier_johto_badge
cobbledollars give @s 24000
