give @s pokebadges:balance_hoenn_badge
cobbledollars give @s 40000
