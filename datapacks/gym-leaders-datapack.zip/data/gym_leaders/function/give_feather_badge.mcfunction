give @s pokebadges:feather_hoenn_badge
cobbledollars give @s 43000
