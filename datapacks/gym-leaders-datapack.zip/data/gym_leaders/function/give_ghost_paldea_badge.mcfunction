give @s pokebadges:ghost_paldea_badge
cobbledollars give @s 266000
