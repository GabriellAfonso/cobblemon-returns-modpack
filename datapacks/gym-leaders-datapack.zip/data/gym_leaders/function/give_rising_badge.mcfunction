give @s pokebadges:rising_johto_badge
cobbledollars give @s 26000
