give @s pokebadges:mine_sinnoh_badge
cobbledollars give @s 72000
