give @s pokebadges:storm_johto_badge
cobbledollars give @s 20000
