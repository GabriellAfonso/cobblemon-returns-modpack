give @s pokebadges:cliff_kalos_badge
cobbledollars give @s 129000
