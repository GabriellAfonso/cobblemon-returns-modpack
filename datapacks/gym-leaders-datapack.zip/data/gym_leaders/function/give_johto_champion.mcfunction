cobbledollars give @s 52000
