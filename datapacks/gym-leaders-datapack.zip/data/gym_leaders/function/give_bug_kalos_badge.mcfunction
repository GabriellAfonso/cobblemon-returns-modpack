give @s pokebadges:bug_kalos_badge
cobbledollars give @s 123000
