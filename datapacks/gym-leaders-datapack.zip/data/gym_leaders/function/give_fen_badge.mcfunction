give @s pokebadges:fen_sinnoh_badge
cobbledollars give @s 64000
