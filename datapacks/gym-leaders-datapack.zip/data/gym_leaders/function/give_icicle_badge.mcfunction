give @s pokebadges:icicle_sinnoh_badge
cobbledollars give @s 76000
