give @s pokebadges:trio_unova_badge
cobbledollars give @s 84000
