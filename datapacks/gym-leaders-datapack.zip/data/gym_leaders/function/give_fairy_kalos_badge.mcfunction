give @s pokebadges:fairy_kalos_badge
cobbledollars give @s 153000
