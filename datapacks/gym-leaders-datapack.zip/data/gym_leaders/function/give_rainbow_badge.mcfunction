give @s pokebadges:rainbow_kanto_badge
cobbledollars give @s 6000
