give @s pokebadges:water_paldea_badge
cobbledollars give @s 250000
