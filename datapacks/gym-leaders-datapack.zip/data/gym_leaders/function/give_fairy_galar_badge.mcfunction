give @s pokebadges:fairy_galar_badge
cobbledollars give @s 198000
