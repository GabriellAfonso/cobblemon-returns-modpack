give @s pokebadges:quake_unova_badge
cobbledollars give @s 104000
