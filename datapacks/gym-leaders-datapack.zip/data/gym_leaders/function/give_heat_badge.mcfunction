give @s pokebadges:heat_hoenn_badge
cobbledollars give @s 37000
