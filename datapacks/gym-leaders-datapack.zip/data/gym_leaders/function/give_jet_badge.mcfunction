give @s pokebadges:jet_unova_badge
cobbledollars give @s 109000
