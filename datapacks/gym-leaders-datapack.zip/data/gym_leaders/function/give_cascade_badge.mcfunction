give @s pokebadges:cascade_kanto_badge
cobbledollars give @s 4000
