give @s pokebadges:freeze_unova_badge
cobbledollars give @s 114000
