give @s pokebadges:ghost_galar_badge
cobbledollars give @s 191000
